// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "forge-std/Test.sol";

// Interface for ERC20 token
interface IERC20 {
    function totalSupply() external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
}

// Interface for Uniswap V2 Router
interface IUniswapV2Router {
    function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
    function swapExactETHForTokens(uint amountOutMin, address[] calldata path, address to, uint deadline) 
        external payable returns (uint[] memory amounts);
    function swapExactTokensForETH(uint amountIn, uint amountOutMin, address[] calldata path, address to, uint deadline) 
        external returns (uint[] memory amounts);
}

// Interface for WETH
interface IWETH is IERC20 {
    function deposit() external payable;
    function withdraw(uint256) external;
}

contract ForkTest is Test {
    // Mainnet addresses
    address constant USDC = 0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48;
    address constant USDT = 0xdAC17F958D2ee523a2206206994597C13D831ec7;
    address constant WETH = 0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2;
    address constant UNI = 0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984;
    
    // Uniswap V2 Router on mainnet
    address constant UNISWAP_V2_ROUTER = 0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D;
    
    uint256 mainnetFork;
    
    function setUp() public {
        // Create a fork of Ethereum mainnet
        // Note: You need to set MAINNET_RPC_URL environment variable
        string memory rpcUrl = vm.envOr("MAINNET_RPC_URL", string(""));
        
        if (bytes(rpcUrl).length > 0) {
            mainnetFork = vm.createFork(rpcUrl);
            vm.selectFork(mainnetFork);
        } else {
            // Use a public RPC for testing (Alchemy or Infura)
            // For demonstration, we'll skip if no RPC is available
            vm.skip(true);
        }
    }

    // Test 1: Read USDC total supply from mainnet
    function testReadUSDCTotalSupply() public {
        vm.selectFork(mainnetFork);
        
        IERC20 usdc = IERC20(USDC);
        uint256 totalSupply = usdc.totalSupply();
        
        console.log("USDC Total Supply:", totalSupply);
        
        // USDC has 6 decimals
        // Expected: significant supply (billions)
        assertTrue(totalSupply > 0, "USDC should have positive total supply");
        assertTrue(totalSupply > 1e24, "USDC supply should be in billions"); // At least 1 billion USDC
    }

    // Test 2: Read WETH balance of this contract (before any interaction)
    function testReadWETHBalance() public {
        vm.selectFork(mainnetFork);
        
        IERC20 weth = IERC20(WETH);
        uint256 balance = weth.balanceOf(address(this));
        
        console.log("WETH Balance of test contract:", balance);
        assertEq(balance, 0);
    }

    // Test 3: Get Uniswap V2 Router address
    function testUniswapV2RouterAddress() public {
        vm.selectFork(mainnetFork);
        
        // Verify Uniswap V2 Router is deployed at expected address
        assertTrue(UNISWAP_V2_ROUTER != address(0), "Uniswap V2 Router should be deployed");
        
        // Try to call the router (will fail if not a contract, but should work)
        uint256 size;
        assembly {
            size := extcodesize(UNISWAP_V2_ROUTER)
        }
        assertTrue(size > 0, "Uniswap V2 Router should be a contract");
    }

    // Test 4: Simulate ETH to USDC swap quote
    function testGetSwapQuote() public {
        vm.selectFork(mainnetFork);
        
        IUniswapV2Router router = IUniswapV2Router(UNISWAP_V2_ROUTER);
        
        // Get quote for swapping 1 ETH to USDC
        address[] memory path = new address[](2);
        path[0] = WETH;
        path[1] = USDC;
        
        uint256 amountIn = 1e18; // 1 ETH
        uint[] memory amounts = router.getAmountsOut(amountIn, path);
        
        console.log("Input:", amountIn, "WETH");
        console.log("Output:", amounts[1], "USDC");
        
        assertTrue(amounts[1] > 0, "Should get some USDC output");
    }

    // Test 5: Simulate USDT to WETH swap quote
    function testGetSwapQuoteUSDTtoWETH() public {
        vm.selectFork(mainnetFork);
        
        IUniswapV2Router router = IUniswapV2Router(UNISWAP_V2_ROUTER);
        
        address[] memory path = new address[](2);
        path[0] = USDT;
        path[1] = WETH;
        
        uint256 amountIn = 1000e6; // 1000 USDT
        uint[] memory amounts = router.getAmountsOut(amountIn, path);
        
        console.log("Input:", amountIn, "USDT");
        console.log("Output:", amounts[1], "WETH");
        
        assertTrue(amounts[1] > 0, "Should get some WETH output");
    }

    // Test 6: Test multi-hop swap (USDC -> WETH -> UNI)
    function testMultiHopSwapQuote() public {
        vm.selectFork(mainnetFork);
        
        IUniswapV2Router router = IUniswapV2Router(UNISWAP_V2_ROUTER);
        
        address[] memory path = new address[](3);
        path[0] = USDC;
        path[1] = WETH;
        path[2] = UNI;
        
        uint256 amountIn = 1000e6; // 1000 USDC
        uint[] memory amounts = router.getAmountsOut(amountIn, path);
        
        console.log("Input:", amountIn, "USDC");
        console.log("WETH output:", amounts[1]);
        console.log("UNI output:", amounts[2]);
        
        assertTrue(amounts[1] > 0, "Should get WETH output");
        assertTrue(amounts[2] > 0, "Should get UNI output");
    }

    // Test 7: Roll fork to specific block
    function testRollFork() public {
        vm.selectFork(mainnetFork);
        
        // Get current block
        uint256 currentBlock = block.number;
        console.log("Current block:", currentBlock);
        
        // Roll forward 100 blocks
        vm.rollFork(currentBlock + 100);
        
        assertEq(block.number, currentBlock + 100, "Should roll to new block");
    }

    // Test 8: Test price impact on large swap
    function testPriceImpact() public {
        vm.selectFork(mainnetFork);
        
        IUniswapV2Router router = IUniswapV2Router(UNISWAP_V2_ROUTER);
        
        address[] memory path = new address[](2);
        path[0] = WETH;
        path[1] = USDC;
        
        // Small swap
        uint256 smallAmount = 0.1e18;
        uint[] memory smallAmounts = router.getAmountsOut(smallAmount, path);
        
        // Large swap (100x)
        uint256 largeAmount = 10e18;
        uint[] memory largeAmounts = router.getAmountsOut(largeAmount, path);
        
        // Calculate effective price
        uint256 smallPrice = smallAmounts[1] / smallAmount; // USDC per ETH
        uint256 largePrice = largeAmounts[1] / largeAmount;
        
        console.log("Small swap price:", smallPrice);
        console.log("Large swap price:", largePrice);
        
        // Large swap should have worse price (price impact)
        assertTrue(largePrice < smallPrice, "Large swap should have worse price");
    }

    // Test 9: Fork testing explanation
    function testExplainForkFunctions() public view {
        /*
        vm.createSelectFork(url) - Creates a new fork from RPC URL and selects it
        vm.createSelectFork(blockNumber) - Creates a fork at specific block number
        
        vm.selectFork(id) - Switches between different forks
        vm.rollFork(blockNumber) - Moves the current fork to a specific block
        vm.rollFork(blockDelta) - Moves the current fork forward by delta blocks
        
        Benefits of fork testing:
        - Test against real deployed contracts
        - No need to mock external protocols
        - Test real price feeds and liquidity
        - More accurate than unit tests with mocks
        
        Limitations:
        - Requires RPC access to mainnet/testnet
        - Can be slow (network calls)
        - State changes don't persist
        - May fail if mainnet contracts change
        */
    }
}
